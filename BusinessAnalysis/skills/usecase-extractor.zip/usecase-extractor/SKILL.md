---
name: usecase-extractor
description: Extract and structure use cases and user stories from requirements documents, functional specifications, and business analysis documents. Use when users upload requirements documents and want to generate structured use case documentation organized by user roles, or when asked to analyze requirements, extract use cases, create user stories, or transform unstructured requirements into actionable specifications. Supports output in Word (.docx), Excel (.xlsx), and Markdown (.md) formats with multi-language support.
---

# Use Case Extractor

Transform requirements documents and functional specifications into structured, role-based use case documentation following 20+ years of business analysis best practices.

## Overview

This skill analyzes uploaded documents to:
1. Identify all actors and user roles
2. Extract explicit and inferred use cases
3. Generate structured use case documentation with codes, targets, inputs, outputs, and dependencies
4. Organize everything by user role
5. Export in professional formats (Word, Excel, Markdown)

## Workflow

### Step 1: Document Upload Acknowledgment

When user uploads requirements document(s):
1. Acknowledge receipt
2. Confirm document reading
3. Briefly describe document type and apparent scope
4. Proceed to analysis

### Step 2: Comprehensive Document Analysis

Read ALL uploaded documents thoroughly before proceeding. Identify:
- Business domain and context
- Project scope and objectives
- All functional and technical requirements
- Stakeholder needs and expectations
- Constraints and assumptions
- Explicitly stated use cases
- Implicitly described use cases (inferred from requirements)

### Step 3: Actor and Role Identification

Extract and categorize all actors:
- **Explicit actors**: Users, roles, and stakeholders mentioned directly
- **Implicit actors**: Roles inferred from actions and requirements
- **System actors**: External systems, APIs, automated processes

Assign clear identifier prefixes (3 letters, uppercase):
- **ADM** = Administrator
- **USR** = End User / General User
- **DEV** = Developer
- **OPR** = Operator
- **MGR** = Manager
- **SYS** = System (automated processes)
- **API** = API Consumer / External System
- **AUD** = Auditor
- **SUP** = Support Staff
- **CST** = Customer
- Create custom prefixes for domain-specific roles as needed (e.g., DOC for Doctor, TCH for Teacher)

### Step 4: Use Case Extraction and Numbering

For each identified role:
1. Extract explicit use cases already defined in document
2. Infer use cases from functional requirements, business processes, and user needs
3. Assign sequential numbering starting at 001 for each role prefix
   - Format: `[PREFIX]-[NUMBER]` (e.g., ADM-001, ADM-002, USR-001)
4. Maintain logical order based on workflow or document structure

### Step 5: Detailed Information Extraction

For each use case, extract and structure:

**Code**: `[PREFIX]-[NUMBER]`

**Name**: Concise, action-oriented name (3-7 words)
- Use verbs: Create, Update, Delete, View, Generate, Approve, Configure, Process
- Example: "Register New User", "Generate Monthly Report", "Approve Purchase Order"

**Title**: `[PREFIX]-[NUMBER]: [Name]`
- Example: `ADM-001: Configure System Settings`

**Target**: Clear goal description (1-3 sentences)
- Explain what user wants to accomplish
- Describe business value and purpose
- Include relevant context

**Input Data**: Comprehensive list categorized as:

*Mandatory* (required):
- Authentication/authorization credentials
- Primary data fields and values
- Required documents or files
- Preconditions
- Configuration parameters
- Validation criteria

*Optional* (enhance functionality):
- Additional data fields
- Optional documents or attachments
- Preferences and settings
- Contextual information
- Historical data

**Output Data**: Complete list of all outputs, results, and effects:
- Data created/modified (records, documents, files)
- Results (calculations, reports, analytics)
- Artifacts (documents, exports, printouts)
- Notifications (emails, alerts, messages)
- Events (triggered processes, workflow steps)
- Side effects (logs, audit records, cache updates)
- Status changes (state transitions, flags)
- User feedback (confirmations, error messages)

**Dependencies**: Related use cases with relationship type:
- Format: `CODE-XXX: Brief description (relationship type)`
- Relationship types: prerequisite, data dependency, workflow sequence, shared resource, triggering
- Example: `USR-001: User Authentication (prerequisite)`, `ADM-005: View Audit Log (related)`

### Step 6: Language Selection

BEFORE generating output, prompt user:

```
Which language should be used for the output document?

Default: English

Please specify your preferred language, or press Enter for English.
```

Wait for user response.

### Step 7: Format Selection

Prompt user:

```
Please choose the output format(s) for your use case documentation:

1. Word Document (.docx) - Professional formatted document
2. Excel Spreadsheet (.xlsx) - Structured table format
3. Markdown File (.md) - Developer-friendly format
4. Multiple formats - Specify which combination (e.g., "Word and Excel")

Please enter your choice (1, 2, 3, or 4):
```

Wait for user response.

### Step 8: Output Generation

Generate downloadable artifact(s) in selected format(s) with role-based organization.

## Output Structure

All formats follow this organization:

```
# [Document Title]
Use Cases and User Stories Analysis

## Executive Summary
- Total roles identified: X
- Total use cases: X
- Total user stories: X
- Document(s) analyzed: [filenames]
- Analysis date: [date]

## Role: [Role Name] ([PREFIX])
[Description of role and responsibilities]

### Use Case [PREFIX]-001: [Name]

**Code**: [PREFIX]-001

**Name**: [Descriptive name]

**Title**: [PREFIX]-001: [Descriptive name]

**Target**: [Detailed description of main goal and business value]

**Input Data**:

*Mandatory*:
- [Input item 1]
- [Input item 2]
- [Input item 3]

*Optional*:
- [Optional input 1]
- [Optional input 2]

**Output Data**:
- [Output item 1]
- [Output item 2]
- [Output item 3]

**Dependencies**:
- [CODE-XXX]: [Brief description (relationship type)]
- [CODE-YYY]: [Brief description (relationship type)]

---

[Repeat for each use case within role]

## Role: [Next Role Name] ([NEXT PREFIX])
[Continue with next role...]
```

## Format-Specific Requirements

### Word Document (.docx)
- Professional formatting with clear section headers
- Use tables or formatted paragraphs
- Table of contents for lengthy documents
- Consistent styling throughout
- Page breaks between major role sections
- Use docx skill if needed

### Excel Spreadsheet (.xlsx)
- Columns: Code | Name | Title | Role | Target | Input Data (Mandatory) | Input Data (Optional) | Output Data | Dependencies
- One row per use case
- Freeze top row for scrolling
- Apply filters to all columns
- Color coding for different roles (optional)
- Auto-fit column widths
- Summary sheet with statistics
- Use xlsx skill if needed

### Markdown File (.md)
- Clear heading hierarchy (# for roles, ## for use cases)
- Bold labels for field names
- Bullet points for lists
- Consistent formatting
- Version control friendly
- No special processing needed

## Quality Guidelines

### Relevance-Based Detail Level

**High-Priority Use Cases** (core functionality, critical for business):
- Detailed Target descriptions (3-5 sentences)
- Comprehensive Input/Output lists (5-15 items each)
- Thorough dependency documentation

**Medium-Priority Use Cases** (supporting functionality):
- Moderate Target descriptions (2-3 sentences)
- Essential Input/Output lists (3-8 items each)
- Important dependencies

**Low-Priority Use Cases** (edge cases, infrequent use):
- Concise Target descriptions (1-2 sentences)
- Core Input/Output lists (2-5 items each)
- Critical dependencies only

### Writing Standards

- **User-focused**: Clear, understandable language for end users
- **Specific**: Avoid vague terms; specify exactly what data/actions
- **Unambiguous**: Break complex statements into clear concepts
- **Evidence-based**: Base all statements on actual document content
- **No assumptions**: If inferring, use clear logical reasoning and note it
- **Consistent terminology**: Use same terms throughout for same concepts

### Formatting

- Use **bold** for field labels and important concepts
- Use bullet points for lists
- Use numbered lists for sequential steps
- Create appropriate white space
- Define acronyms on first use

## Edge Cases

### Unclear/Incomplete Documents
- Extract with confidence what you can
- Create "Flagged Items" section for ambiguities
- Suggest clarifying questions
- Provide best-effort inferences with clear notation

### Contradictory Requirements
- Note both contradictory statements
- Explain the conflict
- Suggest possible resolutions
- Ask for user guidance

### Missing Critical Information
- Note explicitly what's missing
- Explain importance
- Suggest where to find information
- Continue with available information

### Very Large Documents (100+ pages)
- Offer to process in sections
- Create summary structure first
- Generate detailed use cases per section
- Combine into final output

## Final Summary

After completing analysis, provide:

**Statistics**:
- Total roles identified
- Total use cases extracted
- Total user stories (if applicable)
- Dependency relationships mapped

**Coverage Assessment**:
- Document sections analyzed
- Confidence level (high/medium/low)
- Areas needing clarification

**Key Insights**:
- Most complex roles
- Critical dependencies
- Potential gaps or risks

**Next Steps Recommendation**:
- Follow-up questions
- Stakeholder review areas
- Integration suggestions
