# Use Case Extraction Examples

This reference provides detailed examples of use case extraction patterns across different document types and domains.

## Example 1: E-Commerce Platform Requirements

### Source Requirement
"The system shall allow registered users to add products to their shopping cart, view cart contents, update quantities, and proceed to checkout. Users must be authenticated to access cart functionality."

### Extracted Use Cases

**Role: Customer (CST)**

#### Use Case CST-001: Add Product to Cart

**Code**: CST-001

**Name**: Add Product to Cart

**Title**: CST-001: Add Product to Cart

**Target**: Enable customers to select products and add them to their shopping cart for later purchase, maintaining shopping session across page navigations and allowing incremental cart building before final checkout.

**Input Data**:

*Mandatory*:
- User authentication token
- Product ID
- Quantity (default: 1)
- Product availability status

*Optional*:
- Product variant (size, color)
- Gift wrapping preference
- Special instructions

**Output Data**:
- Updated cart item count
- Updated cart total amount
- Confirmation message
- Updated cart session
- Product availability notification (if low stock)
- Cart persistence record

**Dependencies**:
- CST-000: User Authentication (prerequisite)
- CST-003: View Product Details (data dependency)

#### Use Case CST-002: View Shopping Cart

**Code**: CST-002

**Name**: View Shopping Cart

**Title**: CST-002: View Shopping Cart

**Target**: Allow customers to review all items currently in their shopping cart, see pricing details, and make decisions about proceeding to checkout or continuing shopping.

**Input Data**:

*Mandatory*:
- User authentication token
- Active cart session ID

*Optional*:
- Promotional code (for preview)
- Shipping postal code (for estimate)

**Output Data**:
- List of cart items with details
- Item-level pricing
- Subtotal
- Tax estimate
- Shipping estimate
- Grand total
- Availability status for each item
- Promotional savings (if applicable)

**Dependencies**:
- CST-001: Add Product to Cart (data dependency)
- CST-000: User Authentication (prerequisite)

---

## Example 2: Healthcare Management System

### Source Requirement
"Medical staff must be able to access patient records, view medical history, update diagnoses, prescribe medications, and schedule follow-up appointments. All actions must be logged for HIPAA compliance."

### Extracted Use Cases

**Role: Medical Staff (MED)**

#### Use Case MED-001: Access Patient Record

**Code**: MED-001

**Name**: Access Patient Record

**Title**: MED-001: Access Patient Record

**Target**: Enable medical staff to securely retrieve comprehensive patient information including demographics, medical history, current medications, allergies, and recent visits to support clinical decision-making and continuity of care.

**Input Data**:

*Mandatory*:
- Staff authentication credentials
- Staff role and permissions
- Patient identifier (MRN or SSN)
- Access reason/justification
- Access timestamp

*Optional*:
- Specific record section filter
- Date range filter
- Related family member records flag

**Output Data**:
- Patient demographic information
- Medical history summary
- Active medications list
- Known allergies and adverse reactions
- Recent visit summaries
- Current diagnoses
- Insurance information
- Emergency contact details
- HIPAA-compliant access log entry
- Staff notification of sensitive information flags

**Dependencies**:
- MED-000: Staff Authentication (prerequisite)
- AUD-001: HIPAA Compliance Logging (shared resource)

**Role: Auditor (AUD)**

#### Use Case AUD-001: HIPAA Compliance Logging

**Code**: AUD-001

**Name**: HIPAA Compliance Logging

**Title**: AUD-001: HIPAA Compliance Logging

**Target**: Automatically capture all access and modifications to patient records to maintain comprehensive audit trail for regulatory compliance, security monitoring, and breach investigation capabilities.

**Input Data**:

*Mandatory*:
- User ID and role
- Action type (view, edit, create, delete)
- Patient ID
- Timestamp
- Access location (IP address, workstation)
- Data fields accessed or modified

*Optional*:
- Session ID
- Access justification
- Related clinical context
- Supervising physician ID

**Output Data**:
- Immutable audit log entry
- Compliance report data point
- Security monitoring alert (if suspicious pattern)
- Timestamp verification record
- Digital signature of log entry
- Backup compliance record

**Dependencies**:
- ALL use cases involving patient data (triggered by)

---

## Example 3: Financial Trading Platform

### Source Requirement
"The platform must support real-time trade execution with pre-trade risk checks, post-trade confirmation, and automated regulatory reporting."

### Extracted Use Cases

**Role: Trader (TRD)**

#### Use Case TRD-001: Execute Trade Order

**Code**: TRD-001

**Name**: Execute Trade Order

**Title**: TRD-001: Execute Trade Order

**Target**: Enable traders to submit buy or sell orders for financial instruments with real-time execution, ensuring compliance with risk limits and regulatory requirements while providing immediate confirmation and position updates.

**Input Data**:

*Mandatory*:
- Trader authentication and authorization
- Security identifier (ISIN, ticker)
- Order type (market, limit, stop)
- Quantity
- Side (buy/sell)
- Account/portfolio ID
- Current market price

*Optional*:
- Limit price (for limit orders)
- Stop price (for stop orders)
- Time in force (day, GTC, IOC)
- Execution instructions (all-or-none)
- Algorithmic trading strategy

**Output Data**:
- Order confirmation ID
- Execution price(s)
- Filled quantity
- Remaining quantity (if partial fill)
- Commission charged
- Updated portfolio position
- Updated cash balance
- Trade confirmation document
- Regulatory reporting record
- Market data update trigger
- Risk metrics recalculation trigger
- Confirmation notification (email, SMS)

**Dependencies**:
- SYS-001: Pre-Trade Risk Check (prerequisite)
- SYS-002: Market Data Feed (data dependency)
- TRD-000: Trader Authentication (prerequisite)
- REG-001: Regulatory Trade Reporting (triggering)

**Role: System (SYS)**

#### Use Case SYS-001: Pre-Trade Risk Check

**Code**: SYS-001

**Name**: Pre-Trade Risk Check

**Title**: SYS-001: Pre-Trade Risk Check

**Target**: Automatically validate proposed trades against risk limits, margin requirements, and regulatory constraints before execution to prevent violations and protect firm capital.

**Input Data**:

*Mandatory*:
- Proposed trade details
- Current portfolio positions
- Account balance and margin
- Risk limit parameters
- Market volatility data
- Regulatory constraints

*Optional*:
- Historical trade patterns
- Correlation data
- Stress test scenarios
- Counterparty exposure

**Output Data**:
- Risk check result (pass/fail)
- Risk utilization percentage
- Margin requirement calculation
- Limit breach warnings
- Risk metrics update
- Approval/rejection notification
- Audit log entry
- Alternative trade suggestions (if rejected)

**Dependencies**:
- None (prerequisite for trading)

---

## Common Patterns

### Pattern 1: CRUD Operations

Basic create-read-update-delete operations typically generate 4 use cases per entity:

- **[ROLE]-XXX: Create [Entity]** - Add new record
- **[ROLE]-XXY: View [Entity]** - Read existing record
- **[ROLE]-XXZ: Update [Entity]** - Modify existing record
- **[ROLE]-XYZ: Delete [Entity]** - Remove record

### Pattern 2: Workflow Sequences

Multi-step business processes generate sequential use cases with clear dependencies:

1. Initiation use case (no prerequisites)
2. Processing use cases (depend on initiation)
3. Review/approval use cases (depend on processing)
4. Completion use cases (depend on approval)
5. Notification use cases (triggered by completion)

### Pattern 3: Role Hierarchies

When roles have inheritance, organize use cases accordingly:

- **General User** role: Base functionality available to all
- **Power User** role: Extended functionality
- **Administrator** role: System management functionality
- Each specialized role includes implicit access to lower-level use cases

### Pattern 4: System Integration

External system interactions generate specific patterns:

- **[ROLE]-XXX: Trigger [Integration]** - Initiate external call
- **SYS-XXX: Process [Integration] Response** - Handle callback
- **SYS-XXY: Handle [Integration] Error** - Exception handling
- **AUD-XXX: Log [Integration] Transaction** - Compliance tracking

---

## Extraction Tips

### Finding Implicit Use Cases

**From "shall statements"**: Each "system shall" typically implies a use case
- "System shall validate" → Validation use case
- "System shall notify" → Notification use case
- "System shall calculate" → Calculation use case

**From user needs**: Convert needs to actions
- "Users need to track orders" → "View Order Status" use case
- "Admins need visibility" → "Generate Admin Dashboard" use case

**From business processes**: Each process step is a use case
- "Approval workflow" → Multiple use cases for submit, review, approve, reject

**From data flows**: Data movement implies use cases
- "Data exported to warehouse" → "Export Data to Warehouse" use case
- "Reports generated nightly" → "Generate Scheduled Reports" use case

### Determining Dependencies

**Prerequisites**: Use case A must complete before B can start
- Login before accessing features
- Search before view details
- Create account before place order

**Data Dependencies**: Use case A creates data needed by B
- Create product before add to cart
- Define user before assign permissions
- Configure settings before apply settings

**Workflow Sequences**: Natural business process order
- Submit application → Review application → Approve/Reject
- Create order → Process payment → Ship order

**Triggering**: Use case A automatically starts B
- Order completion triggers inventory update
- User registration triggers welcome email
- Payment success triggers order confirmation
