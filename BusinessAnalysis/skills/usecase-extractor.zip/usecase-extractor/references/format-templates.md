# Output Format Templates

This reference provides detailed templates for each supported output format.

## Markdown Format Template

```markdown
# [Project Name] - Use Cases and User Stories Analysis

**Document Version**: 1.0  
**Analysis Date**: [Current Date]  
**Analyzed Document(s)**: [List of source documents]  
**Prepared By**: Claude Use Case Extractor

---

## Executive Summary

- **Total Roles Identified**: X
- **Total Use Cases Extracted**: X
- **Total User Stories**: X
- **Coverage Assessment**: [High/Medium/Low]
- **Document Sections Analyzed**: [List sections]

### Key Insights

- Most Complex Role: [Role Name] with X use cases
- Critical Dependencies: X dependency relationships identified
- High-Priority Use Cases: X
- Medium-Priority Use Cases: X
- Low-Priority Use Cases: X

---

## Role: [Role Name] ([PREFIX])

**Description**: [2-3 sentence description of the role, its responsibilities, and its position in the system]

**Use Cases Count**: X

---

### Use Case [PREFIX]-001: [Use Case Name]

**Code**: [PREFIX]-001

**Name**: [Descriptive Action-Oriented Name]

**Title**: [PREFIX]-001: [Descriptive Action-Oriented Name]

**Priority**: [High/Medium/Low]

**Target**: [1-3 paragraph description explaining what the user wants to accomplish, the business value, and relevant context. Should clearly articulate the goal and why it matters.]

**Input Data**:

*Mandatory*:
- [Required input item 1 with brief description if needed]
- [Required input item 2]
- [Required input item 3]
- [Additional required inputs...]

*Optional*:
- [Optional input item 1 with brief description]
- [Optional input item 2]
- [Additional optional inputs...]

**Output Data**:
- [Output item 1 - data created or modified]
- [Output item 2 - results or calculations]
- [Output item 3 - notifications or alerts]
- [Output item 4 - side effects like logs]
- [Output item 5 - status changes]
- [Additional outputs...]

**Dependencies**:
- **[CODE-XXX]**: [Use Case Name] *(relationship type: prerequisite)*
- **[CODE-YYY]**: [Use Case Name] *(relationship type: data dependency)*
- **[CODE-ZZZ]**: [Use Case Name] *(relationship type: workflow sequence)*

**User Story Format**:
> As a [Role], I want to [action/goal] so that [business value/benefit].

**Acceptance Criteria**:
1. Given [precondition], when [action], then [expected outcome]
2. Given [precondition], when [action], then [expected outcome]
3. [Additional criteria as appropriate]

---

[Repeat use case structure for each use case in this role]

---

## Role: [Next Role Name] ([NEXT-PREFIX])

[Continue with same structure for each role]

---

## Dependencies Map

### High-Level Workflow Sequences

1. **[Workflow Name]**:
   - [CODE-001]: [Use Case Name]
   - → [CODE-002]: [Use Case Name]
   - → [CODE-003]: [Use Case Name]

2. **[Another Workflow]**:
   - [CODE-XXX]: [Use Case Name]
   - → [CODE-YYY]: [Use Case Name]

### Critical Dependencies Matrix

| Dependent Use Case | Depends On | Relationship Type |
|-------------------|------------|-------------------|
| [CODE-XXX] | [CODE-YYY] | Prerequisite |
| [CODE-AAA] | [CODE-BBB] | Data Dependency |

---

## Flagged Items for Clarification

### Ambiguous Requirements
1. **[Requirement ID/Section]**: [Description of ambiguity] - *Suggestion: [How to clarify]*
2. [Additional ambiguous items...]

### Missing Information
1. **[Topic/Area]**: [What's missing] - *Impact: [Why it matters]*
2. [Additional missing items...]

### Contradictory Requirements
1. **Requirement A vs B**: [Description of contradiction] - *Recommendation: [Suggested resolution]*
2. [Additional contradictions...]

---

## Appendix

### Role Identifier Legend
- **ADM** = Administrator
- **USR** = End User / General User
- **DEV** = Developer
- **[Custom prefixes as defined]**

### Glossary
- **Term 1**: Definition
- **Term 2**: Definition

### Analysis Methodology
Brief description of the extraction approach and any assumptions made.
```

---

## Word Document (.docx) Format Guidelines

### Document Structure

**Title Page**:
- Project Name
- Document Title: "Use Cases and User Stories Analysis"
- Version and Date
- Prepared By

**Table of Contents**:
- Automatically generated with heading styles
- Include page numbers
- Link to sections

**Executive Summary** (Heading 1):
- Summary statistics in a formatted table
- Key insights in bullet points

**Each Role Section** (Heading 1):
- Role name and identifier
- Role description paragraph

**Each Use Case** (Heading 2):
- Use structured tables for consistent layout:

| Field | Content |
|-------|---------|
| **Code** | [PREFIX]-XXX |
| **Name** | [Descriptive Name] |
| **Title** | [Full Title] |
| **Priority** | [High/Medium/Low] |
| **Target** | [Goal description] |

**Input Data Table**:

| Category | Input Item |
|----------|------------|
| Mandatory | [Item 1] |
| Mandatory | [Item 2] |
| Optional | [Item 3] |

**Output Data** (Bulleted list)

**Dependencies** (Formatted list with links if possible)

**Styling Requirements**:
- Heading 1: Role sections (Arial, 16pt, Bold, Navy Blue)
- Heading 2: Use case titles (Arial, 14pt, Bold, Dark Gray)
- Body text: Arial, 11pt
- Tables: Light gray header, alternating row colors
- Page breaks: Before each role section
- Margins: 1 inch all sides
- Line spacing: 1.15

---

## Excel Spreadsheet (.xlsx) Format Guidelines

### Sheet 1: Summary

**Statistics Table**:
| Metric | Value |
|--------|-------|
| Total Roles | X |
| Total Use Cases | X |
| High Priority | X |
| Medium Priority | X |
| Low Priority | X |
| Total Dependencies | X |

**Roles Summary Table**:
| Role Code | Role Name | Use Case Count |
|-----------|-----------|----------------|
| ADM | Administrator | X |
| USR | End User | X |
| ... | ... | ... |

### Sheet 2: Use Cases

**Column Headers** (Row 1, Frozen, Bold, Background Color):
1. Code
2. Role
3. Name
4. Title
5. Priority
6. Target
7. Input Data (Mandatory)
8. Input Data (Optional)
9. Output Data
10. Dependencies
11. User Story

**Data Rows** (Starting Row 2):
- Each use case occupies one row
- Multi-line text where needed (wrap text enabled)
- Data validation for Priority column (High/Medium/Low dropdown)
- Conditional formatting:
  - High Priority: Light red background
  - Medium Priority: Light yellow background
  - Low Priority: Light green background

**Column Widths**:
- Code: 12
- Role: 12
- Name: 25
- Title: 30
- Priority: 10
- Target: 50
- Input Data columns: 40 each
- Output Data: 40
- Dependencies: 35
- User Story: 50

**Features**:
- AutoFilter enabled on header row
- Freeze panes on row 2
- Color-code rows by role (subtle background colors)
- Borders on all cells (light gray)

### Sheet 3: Dependencies Matrix

**Cross-reference table**:
- Rows: All use case codes
- Columns: All use case codes
- Cell values: Relationship type (if dependency exists)

### Sheet 4: Flagged Items

**Columns**:
1. Item Type (Ambiguous/Missing/Contradictory)
2. Reference (Document section or requirement ID)
3. Description
4. Recommendation
5. Priority (High/Medium/Low)
6. Status (Open/Resolved)

---

## Format Selection Logic

**Recommend Word (.docx) when**:
- User needs stakeholder-facing documentation
- Professional presentation is priority
- Document will be printed or shared externally
- User mentions "report", "document", "presentation"

**Recommend Excel (.xlsx) when**:
- User needs to track, filter, or sort use cases
- Multiple team members will collaborate
- Integration with project management tools needed
- User mentions "spreadsheet", "tracking", "filtering", "analysis"

**Recommend Markdown (.md) when**:
- User is developer or technical team
- Version control (Git) integration needed
- Documentation lives in code repository
- User mentions "GitHub", "GitLab", "repository", "version control"

**Recommend Multiple formats when**:
- Mixed audience (technical and business stakeholders)
- Different use cases (presentation + tracking)
- User explicitly requests multiple formats
- Project requires comprehensive documentation package
