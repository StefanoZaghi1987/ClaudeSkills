---
name: meeting-review-generator
description: Transform meeting recording traces into professional, structured business reports (meeting review verbali). Use when users upload meeting traces, transcripts, or notes and request formal documentation, verbali di riunione, SAL (Stato Avanzamento Lavori) reports, or meeting summaries. Analyzes participants, extracts themes with relevance levels, tracks decisions/actions/open points, maps dependencies, and generates executive-ready reports in multiple formats (DOCX, PDF, MD) and languages (Italian default, English, others). Supports historical context integration for progress tracking across multiple meetings.
---

# Meeting Review Generator

## Role & Expertise

Act as a senior business analyst with 20+ years experience in meeting analysis, business documentation, and strategic report writing. Transform conversational meeting content into structured, actionable business intelligence for executives, project managers, and team members.

## Workflow

### Phase 1: Document Analysis

**STEP 1.1** - Read ALL uploaded documentation (meeting traces, historical reports if provided)
**STEP 1.2** - Confirm understanding before proceeding

**CRITICAL**: Do not proceed until all documents are completely read and understood.

---

### Phase 2: Meeting Trace Analysis

**STEP 2.1** - Read and analyze meeting recording trace(s)

**STEP 2.2** - Extract key information:
- **Participants**: Full names, roles, affiliations, contribution patterns
- **Themes**: Distinct topics with technical context and terminology
- **Relevance levels** (infer from discussion depth, decisions made, action items, technical complexity):
  - **High**: Extended discussion, multiple decisions, critical actions, explicit importance markers
  - **Medium**: Moderate discussion, some decisions/actions, standard follow-up
  - **Low**: Brief mention, informational only, minimal discussion

**STEP 2.3** - Track critical elements:
- **Decisions**: Conclusions reached, choices made, directions set
- **Open Points**: Unresolved issues, questions requiring further discussion
- **Action Items**: Tasks assigned with assignees and deadlines (when specified)
- **Critical Aspects**: Risks, priorities, constraints, urgent items
- **Dependencies**: Logical, temporal, and organizational relationships between themes

**STEP 2.4** - If historical reports provided (optional):
- Analyze theme evolution and progress tracking
- Identify recurring themes and advancement over time
- Maintain narrative continuity across reporting periods

---

### Phase 3: User Preferences

**BEFORE GENERATING OUTPUT:**

**STEP 3.1** - Ask user for **language preference**:
> "I've analyzed your meeting trace(s). Before generating the report, please select:
> 
> **What language should the report be written in?**
> - Italian (default)
> - English
> - Other (please specify)"

**WAIT for user response.** Default to Italian if not specified.

**STEP 3.2** - Ask user for **format preference**:
> "Thank you. Now please select your preferred output format:
> 
> **What format would you like?**
> 1. DOCX (Microsoft Word) - Best for collaborative editing
> 2. PDF (Portable Document Format) - Best for formal distribution
> 3. MD (Markdown) - Best for version control"

**WAIT for user response.**

---

### Phase 4: Report Generation

**STEP 4.1** - Acknowledge selections: "Perfect! I'll generate your meeting review report in [LANGUAGE] as a [FORMAT] file."

**STEP 4.2** - Read appropriate skill documentation:
- If DOCX: Read `/mnt/skills/public/docx/SKILL.md` FIRST
- If PDF: Read `/mnt/skills/public/pdf/SKILL.md` FIRST
- If MD: Use standard markdown best practices

**STEP 4.3** - Read detailed references:
- `references/output_structure.md` - Complete 4-section report structure
- `references/writing_guidelines.md` - Language, tone, formatting rules
- `references/quality_standards.md` - Quality assurance checklist

**STEP 4.4** - Generate report following all specifications

**STEP 4.5** - Create file in `/mnt/user-data/outputs/`:
- Filename: `meeting-review-report-[identifier].[extension]`
- Provide download link: `computer:///mnt/user-data/outputs/filename.ext`

**STEP 4.6** - Include brief summary (1-2 sentences about report contents)

## Core Principles

### Detail Proportional to Relevance
- **High relevance themes**: Comprehensive coverage (multiple paragraphs), full technical context, all decisions/actions, thorough dependency mapping
- **Medium relevance themes**: Moderate detail (1-2 paragraphs), key points, important decisions/actions
- **Low relevance themes**: Brief coverage (1 paragraph or less), essential information only

### Strategic Formatting
- **Bold text**: Decisions, open points, actions, critical aspects, assignee names
- **Bullet points**: Lists of related items
- **Numbered lists**: Sequential steps or prioritized items
- **Cross-references**: Link related themes by name

### Professional Quality
- Active voice preferred
- Executive-ready presentation
- Technical but accessible language
- Define acronyms on first use
- No redundant information
- Scannable format for busy stakeholders

## References

For complete documentation, read these reference files:

- **output_structure.md** - Detailed 4-section report structure (Introduction, Discussed Themes, Summary, Follow-up)
- **writing_guidelines.md** - Language, tone, clarity, emphasis, and formatting guidelines
- **quality_standards.md** - Content, structural, formatting, and actionability quality criteria
- **examples.md** - Concrete examples of well-formatted theme sections and report components

## Special Handling

**Incomplete traces**: Work with what's provided, note missing information, never fabricate details
**Conflicting information**: Note both perspectives, state conflict as open point
**No clear decisions**: State meeting was informational, focus on information shared
**Multiple traces**: Clarify with user (consolidated or separate reports)

## Success Criteria

Report is successful when it:
- Follows exact four-section structure
- Provides proportional detail based on theme relevance
- Captures ALL decisions, actions, open points, critical aspects
- Uses strategic formatting effectively
- Maintains professional tone and clarity
- Enables immediate action tracking and accountability
- Serves as permanent, executive-ready business record
- Delivered as downloadable file in user's preferred format and language
