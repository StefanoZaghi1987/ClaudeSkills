# Quality Standards

Comprehensive quality assurance criteria for meeting review reports. Use this checklist to verify report excellence before delivery.

---

## Content Quality Standards

### Completeness
Report captures all essential information from the meeting trace.

#### Verification Checklist
- [ ] **All themes identified**: Every distinct topic discussed is captured
- [ ] **All participants listed**: Every meeting attendee is named in Introduction
- [ ] **All decisions documented**: Every conclusion, choice, or direction is recorded
- [ ] **All action items captured**: Every task assignment is documented
- [ ] **All open points noted**: Every unresolved issue or question is listed
- [ ] **All critical aspects highlighted**: Every risk, priority, or constraint is emphasized

#### Quality Tests
- Cross-reference meeting trace to confirm no major topics are missing
- Scan for decision keywords ("decided," "agreed," "approved," "chose")
- Search for action keywords ("will," "should," "must," "assigned to")
- Look for question keywords ("how," "what if," "should we," "unclear")
- Identify emphasis keywords ("critical," "priority," "urgent," "risk," "constraint")

---

### Accuracy
Report faithfully represents meeting content without fabrication.

#### Verification Checklist
- [ ] **No fabricated details**: All information comes from meeting trace or is reliably inferable
- [ ] **Technical details verified**: Specifications, versions, configurations are accurate
- [ ] **Names spelled correctly**: Participant names consistent and accurate
- [ ] **Dates accurate**: Meeting date and deadlines match trace information
- [ ] **Quotes faithful**: Any direct quotes accurately represent what was said
- [ ] **Context preserved**: Background and rationale maintained from discussion

#### Quality Tests
- Verify each technical term against meeting trace
- Check participant name spelling consistency
- Confirm all numerical data (dates, quantities, metrics)
- Ensure decisions match actual conclusions reached
- Validate action assignments match meeting trace

---

### Relevance
Report maintains appropriate focus and detail levels.

#### Verification Checklist
- [ ] **Proportional detail**: High-relevance themes get comprehensive coverage
- [ ] **Focused content**: All content serves the report's purpose
- [ ] **Appropriate depth**: Technical detail matches theme importance
- [ ] **No tangents**: All information relates to meeting outcomes
- [ ] **Context sufficient**: Enough background for understanding, not excessive

#### Quality Tests
- High-relevance themes should be 3-6+ paragraphs
- Medium-relevance themes should be 1-2 paragraphs
- Low-relevance themes should be 1 paragraph or less
- Verify detail level matches discussion time in trace
- Check that emphasis aligns with explicit importance markers

---

### Context
Report provides sufficient background for understanding.

#### Verification Checklist
- [ ] **Adequate background**: Why themes were discussed is clear
- [ ] **Technical context**: Sufficient information for understanding decisions
- [ ] **Historical continuity**: Previous meeting outcomes referenced when relevant
- [ ] **Organizational context**: Stakeholder relationships and responsibilities clear
- [ ] **Dependency clarity**: Relationships between themes are explained

#### Quality Tests
- Ask: "Could someone who wasn't in the meeting understand this?"
- Verify technical terms are defined or explained
- Check that decisions include rationale when provided
- Ensure acronyms are spelled out on first use
- Confirm cross-references provide adequate context

---

## Structural Quality Standards

### Four-Section Adherence
Report follows the exact four-section structure.

#### Required Sections
1. **Introduction** - Meeting overview and participants
2. **Discussed Themes** - Detailed analysis of each theme
3. **Summary** - Consolidated decisions, open points, actions, critical aspects
4. **Follow-up** - Actionable next steps with accountability

#### Verification Checklist
- [ ] All four sections present
- [ ] Sections in correct order
- [ ] Section purposes fulfilled
- [ ] No sections missing or combined inappropriately

---

### Logical Flow
Report creates coherent narrative across sections.

#### Verification Checklist
- [ ] **Introduction previews**: Sets context for themes that follow
- [ ] **Theme organization**: Themes ordered logically (by dependency, chronology, or importance)
- [ ] **Dependencies clear**: Relationships between themes are explicit
- [ ] **Summary consolidates**: No new information introduced
- [ ] **Follow-up connects**: Actions clearly link back to themes
- [ ] **Transitions smooth**: Sections flow naturally

#### Quality Tests
- Read Introduction → verify it prepares reader for themes
- Check theme order → does it make narrative sense?
- Verify dependencies → are all cross-references accurate?
- Scan Summary → does it consolidate without introducing new info?
- Review Follow-up → can each action be traced to a theme?

---

### Consistent Structure
Each theme section follows the same organizational pattern.

#### Theme Section Components (in order when applicable)
1. Context and background
2. Technical details
3. Discussion points
4. Decisions (bold)
5. Open points (bold)
6. Action items (bold)
7. Dependencies
8. Critical aspects (bold)

#### Verification Checklist
- [ ] All theme sections use consistent structure
- [ ] Component order is logical and maintained
- [ ] Similar themes receive similar treatment
- [ ] Cross-references use consistent format

---

### Cross-Reference Accuracy
All internal references are correct and helpful.

#### Verification Checklist
- [ ] Theme names referenced accurately
- [ ] Section references correct (e.g., "See Summary section")
- [ ] Dependencies properly linked
- [ ] No broken references
- [ ] Cross-references add value

#### Quality Tests
- Follow each cross-reference → verify it points to correct location
- Check theme name consistency → all references use same title
- Verify dependency logic → referenced theme actually relates
- Confirm reference necessity → does it help reader understanding?

---

## Formatting Quality Standards

### Strategic Bolding
Bold text effectively highlights key information.

#### Verification Checklist
- [ ] **All decisions bolded** with "Decision:" label
- [ ] **All open points bolded** with "Open Point:" label
- [ ] **All action items bolded** (action statement)
- [ ] **All assignee names bolded**
- [ ] **All critical aspects bolded** (risks, priorities, constraints)
- [ ] **Bolding not overused** (only essential information)

#### Quality Tests
- Scan document for bolded text → should jump to all critical information
- Verify label consistency → all decisions start with "**Decision**:"
- Check action items → assignee names should be immediately visible
- Test scannability → can you find all decisions in 10 seconds?

---

### Effective Lists
Bullet points and numbered lists enhance readability.

#### Verification Checklist
- [ ] **Bullets for unordered items**: Related items, discussion points, risks
- [ ] **Numbers for ordered items**: Sequential steps, prioritized actions
- [ ] **Parallel structure**: All items in a list use consistent grammar
- [ ] **Appropriate nesting**: Sub-bullets add detail without confusion
- [ ] **Not overused**: Lists serve clear purpose

#### Quality Tests
- Check bullet parallelism → all start with verb or all start with noun
- Verify number logic → is sequence/priority clear?
- Test nesting → can you understand hierarchy easily?
- Confirm necessity → could prose work better in some cases?

---

### Clear Headers
Section and subsection titles are descriptive and navigable.

#### Verification Checklist
- [ ] **Section headers clear**: Introduction, Discussed Themes, Summary, Follow-up
- [ ] **Theme titles descriptive**: "Database Migration Strategy" not "Database"
- [ ] **Summary subsections**: Decisions Recap, Open Points, Actions, Critical Aspects
- [ ] **Header hierarchy logical**: Consistent use of ##, ###, ####
- [ ] **Navigation enabled**: Headers allow quick location of content

#### Quality Tests
- Read only headers → can you understand report structure?
- Check theme titles → are they specific and clear?
- Verify hierarchy → does markdown/Word heading structure make sense?
- Test navigation → can you quickly find a specific theme?

---

### Readable Paragraphs
Paragraph length and structure optimize comprehension.

#### Verification Checklist
- [ ] **Appropriate length**: 3-6 sentences typically, adjusted for content
- [ ] **Clear topic sentences**: Each paragraph has obvious main idea
- [ ] **Logical breaks**: Separate paragraphs for distinct concepts
- [ ] **No walls of text**: Long sections broken into digestible chunks
- [ ] **Smooth flow**: Transitions connect paragraphs

#### Quality Tests
- Scan for very long paragraphs (8+ sentences) → consider breaking
- Verify each paragraph → single main idea?
- Check transitions → does one paragraph lead naturally to next?
- Test comprehension → can you grasp paragraph's point quickly?

---

### Professional Appearance
Document looks polished and executive-ready.

#### Verification Checklist
- [ ] **Consistent formatting**: All similar elements formatted the same way
- [ ] **Clean whitespace**: Generous but not excessive spacing
- [ ] **Aligned structure**: Lists, indentation, spacing aligned properly
- [ ] **No formatting errors**: No stray characters, broken formatting
- [ ] **Print/PDF ready**: Document looks professional in final format

#### Format-Specific Checks

**For DOCX:**
- [ ] Styles applied consistently
- [ ] Headers use Word heading styles
- [ ] Page breaks appropriate
- [ ] Margins suitable for printing

**For PDF:**
- [ ] Professional font and sizing
- [ ] Clear visual hierarchy
- [ ] Bookmarks/navigation enabled (if applicable)
- [ ] Print-ready appearance

**For Markdown:**
- [ ] Valid markdown syntax
- [ ] Renders correctly in preview
- [ ] Links functional
- [ ] Code blocks formatted properly

---

## Actionability Quality Standards

### Clear Actions
Every action item is specific and actionable.

#### Verification Checklist
- [ ] **Specific tasks**: Clear what needs to be done
- [ ] **Unambiguous wording**: No vague language
- [ ] **Measurable when possible**: Can determine when complete
- [ ] **Single responsibility**: Each action has one primary owner
- [ ] **Realistic scope**: Actions are achievable

#### Quality Tests
- Read each action → can someone start immediately?
- Check for vague verbs → "improve" vs "increase by 20%"
- Verify clarity → would two people interpret this the same way?
- Test measurability → how will completion be verified?

---

### Assigned Responsibility
All actions have clear ownership.

#### Verification Checklist
- [ ] **Assignee identified**: Every action has a responsible party
- [ ] **Names bolded**: Assignees visually prominent
- [ ] **One primary owner**: No diffused responsibility
- [ ] **Team vs. individual**: Clarity on whether team or person is responsible
- [ ] **Contact info included** when helpful

#### Quality Tests
- Scan action items → is assignee immediately visible?
- Check ambiguity → no "the team" without specifying which team
- Verify realism → does this person have authority/capacity?

---

### Tracked Dependencies
Prerequisites and blockers are clearly identified.

#### Verification Checklist
- [ ] **Dependencies stated**: Prerequisites listed for each action
- [ ] **Blockers identified**: What might prevent completion
- [ ] **Sequence clear**: Order of execution specified when relevant
- [ ] **Cross-team dependencies**: Handoffs and coordination points noted
- [ ] **Resource needs**: Required resources identified

#### Quality Tests
- Check each action → are dependencies explicit?
- Verify feasibility → can this be done with stated dependencies?
- Test completeness → are all blockers identified?
- Confirm clarity → are prerequisite relationships clear?

---

### Timeline Awareness
Deadlines and timeframes are captured appropriately.

#### Verification Checklist
- [ ] **Deadlines included**: When specified in meeting trace
- [ ] **Timeframes noted**: When dates not specified but duration mentioned
- [ ] **Relative dates appropriate**: "Before next meeting" when relevant
- [ ] **Priority reflected**: Urgent items clearly marked
- [ ] **Realistic expectations**: Timeline considerations noted

#### Quality Tests
- Check date format consistency
- Verify all mentioned deadlines are captured
- Confirm priority aligns with timeline
- Test clarity → is urgency obvious?

---

### Success Criteria
Completion can be verified objectively.

#### Verification Checklist
- [ ] **Measurable outcomes**: When specified in trace
- [ ] **Deliverables clear**: What will be produced
- [ ] **Quality standards**: When discussed in meeting
- [ ] **Acceptance criteria**: How completion will be judged
- [ ] **Stakeholder approval**: When sign-off required

#### Quality Tests
- Read each action → how will we know it's done?
- Check specificity → are criteria concrete or vague?
- Verify traceability → do criteria come from meeting discussion?

---

## Final Quality Gate

Before delivering the report, confirm:

### Content Completeness
- [ ] All themes, decisions, actions, open points captured
- [ ] All participants identified
- [ ] No major gaps in coverage

### Structural Integrity
- [ ] Four-section structure followed
- [ ] Consistent theme formatting
- [ ] Logical flow throughout

### Formatting Excellence
- [ ] Strategic bolding applied
- [ ] Effective use of lists
- [ ] Clear, descriptive headers
- [ ] Professional appearance

### Actionability
- [ ] All actions specific and clear
- [ ] All assignees identified
- [ ] Dependencies mapped
- [ ] Timeline awareness present

### Language Quality
- [ ] Appropriate tone and formality
- [ ] Technical accuracy
- [ ] Clear and precise wording
- [ ] No ambiguities

### User Requirements
- [ ] Correct language (Italian/English/other)
- [ ] Correct format (DOCX/PDF/MD)
- [ ] File in /mnt/user-data/outputs/
- [ ] Download link provided

---

## Excellence Indicators

Your report achieves excellence when:

✓ **Executives can scan it in 60 seconds** and grasp all key decisions
✓ **Project managers can immediately create tasks** from Follow-up section
✓ **Team members can find their actions** in under 10 seconds
✓ **Stakeholders can understand context** without attending the meeting
✓ **Auditors can verify accountability** through clear assignment and tracking
✓ **Historical continuity is maintained** across multiple meetings
✓ **No questions of "what was decided?"** remain after reading
✓ **Action items can be imported** directly into project management tools
✓ **Professional distribution is possible** without further editing
✓ **Long-term reference value is high** for future decision-making
